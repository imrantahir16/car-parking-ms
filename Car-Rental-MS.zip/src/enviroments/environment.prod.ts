export const environment = {
  production: true,
  // baseUrl: '/api/v1',
  baseUrl: 'https://localhost:7005/api/v1'
};
