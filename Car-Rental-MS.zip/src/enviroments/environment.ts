export const environment = {
  production: false,
  // baseUrl: '/api/v1',
  baseUrl: 'https://localhost:7005/api/v1'
};
